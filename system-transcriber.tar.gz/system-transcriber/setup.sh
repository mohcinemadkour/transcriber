#!/usr/bin/env bash
# setup.sh — Install dependencies for System Audio Transcriber

set -e

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║     System Audio Transcriber — Setup         ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# Check Python
if ! command -v python3 &>/dev/null; then
  echo "✗  Python 3 not found. Install from https://python.org"
  exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "✓  Python $PYTHON_VERSION detected"

# Install pip packages
echo ""
echo "Installing Python dependencies…"
pip install faster-whisper sounddevice numpy rich --quiet

echo ""
echo "✓  All Python packages installed"
echo ""

# OS-specific loopback instructions
OS="$(uname -s)"
echo "══════════════════════════════════════════════"
echo "  System audio loopback setup (one-time)"
echo "══════════════════════════════════════════════"

if [[ "$OS" == "Darwin" ]]; then
  echo ""
  echo "macOS detected:"
  echo "  1. Install BlackHole (free virtual audio driver):"
  echo "     https://existential.audio/blackhole/"
  echo "  2. Open System Settings > Sound > Output"
  echo "     → Set to 'BlackHole 2ch'  (or create a Multi-Output Device"
  echo "       in Audio MIDI Setup to hear audio AND capture it)"
  echo "  3. Run the app and select 'BlackHole 2ch' as the input device."
  echo ""

elif [[ "$OS" == "Linux" ]]; then
  echo ""
  echo "Linux / PulseAudio detected:"
  echo "  A monitor source is usually auto-available."
  echo "  Run: pactl list sources short"
  echo "  Look for a source ending in '.monitor'"
  echo "  Select that device index in the app."
  echo ""
  echo "  If using PipeWire:"
  echo "    pw-record --list-targets   (find the monitor)"
  echo ""

else
  echo ""
  echo "Windows detected:"
  echo "  Option A — Stereo Mix (built-in, if supported):"
  echo "    Right-click speaker icon > Sounds > Recording"
  echo "    Right-click in empty area > Show Disabled Devices"
  echo "    Enable 'Stereo Mix' and set as default."
  echo ""
  echo "  Option B — VB-Cable (free virtual cable):"
  echo "    https://vb-audio.com/Cable/"
  echo "    Set Windows audio output to 'CABLE Input (VB-Audio)'."
  echo "    Select 'CABLE Output' as the input device in the app."
  echo ""
fi

echo "══════════════════════════════════════════════"
echo ""
echo "  Run the app:"
echo "    python3 transcriber.py"
echo ""
